package com.example.notesapp;

public interface Constants {
    String
            id = "id",
            noteTitle = "noteTitle",
            noteSubtitle = "noteSubtitle",
            noteContent = "noteContent",
            createTime = "createTime";

}
