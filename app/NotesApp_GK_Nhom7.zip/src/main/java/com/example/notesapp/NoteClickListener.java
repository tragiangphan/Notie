package com.example.notesapp;

public interface NoteClickListener {
    void onClickItem(NoteModel noteModel);
}
